package com.capg.psa.domain.model.aggregate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

import org.seedstack.business.domain.BaseAggregateRoot;

@Entity
public class Bank extends BaseAggregateRoot<String> {
   
	@Id
	@Column(name="bank_id")
	Integer bankCode;
	
	@Column(name="bank_name")
	String bankName;
	
	@Column(name="branch_id")
	Integer branchCode;
	
	@Column(name="branch_name")
	String branchName;
	
	public Integer getBankCode() {
		return bankCode;
	}
	public void setBankCode(Integer bankCode) {
		this.bankCode = bankCode;
	}
	public String getBankName() {
		return bankName;
	}
	public void setBankName(String bankName) {
		this.bankName = bankName;
	}
	public Integer getBranchCode() {
		return branchCode;
	}
	public void setBranchCode(Integer branchCode) {
		this.branchCode = branchCode;
	}
	public String getBranchName() {
		return branchName;
	}
	public void setBranchName(String branchName) {
		this.branchName = branchName;
	}
	
	
	
}
