package com.capg.psa.domain.model.aggregate;

import javax.persistence.Column;
import javax.persistence.Id;

import org.seedstack.business.domain.BaseAggregateRoot;

public class Account extends BaseAggregateRoot<String>{
 
	@Id
	@Column(name="accNo")
	Integer accountNumber;
	
	@Column(name="accType")
	String accountType;
	public Integer getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(Integer accountNumber) {
		this.accountNumber = accountNumber;
	}
	public String getAccountType() {
		return accountType;
	}
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}
}
