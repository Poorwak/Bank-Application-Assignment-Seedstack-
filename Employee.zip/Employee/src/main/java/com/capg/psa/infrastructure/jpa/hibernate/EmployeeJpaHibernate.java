package com.capg.psa.infrastructure.jpa.hibernate;

import java.util.List;

import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;

import org.seedstack.jpa.BaseJpaRepository;

import com.capg.psa.domain.model.aggregate.Employee;
import com.capg.psa.domain.repository.EmployeeRepository;

public class EmployeeJpaHibernate extends BaseJpaRepository<Employee, Integer> implements EmployeeRepository {

	@Override
	public List<Employee> all() {
		CriteriaBuilder cb = getEntityManager().getCriteriaBuilder();
		
		CriteriaQuery<Employee> cquery = cb.createQuery(getAggregateRootClass());
		cquery.from(getAggregateRootClass());
		
		TypedQuery<Employee> tquery = getEntityManager().createQuery(cquery);
		
		return tquery.getResultList();
	}

	
}
