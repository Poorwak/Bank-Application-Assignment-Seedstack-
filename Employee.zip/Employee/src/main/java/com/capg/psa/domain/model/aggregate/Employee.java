package com.capg.psa.domain.model.aggregate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

import org.seedstack.business.domain.BaseAggregateRoot;

@Entity
public class Employee extends BaseAggregateRoot<Integer>{

	@Id
	@Column(name="employee_id")
	Integer empId;
	
	@Column(name="employee_name")
	String empName;
	
	@Column(name="employee_salary")
	Float empSalary;
	
	public Integer getEmpId() {
		return empId;
	}
	public void setEmpId(Integer empId) {
		this.empId = empId;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public Float getEmpSalary() {
		return empSalary;
	}
	public void setEmpSalary(Float empSalary) {
		this.empSalary = empSalary;
	}
}
