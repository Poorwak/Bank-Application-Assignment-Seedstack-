package com.capg.psa.domain.repository;

import java.util.List;

import org.seedstack.business.domain.Repository;

import com.capg.psa.domain.model.aggregate.Employee;

public interface EmployeeRepository extends Repository<Employee, Integer> {

	public List<Employee> all();
}
