package com.capg.psa.infrastructure.jpa.hibernate;

import java.util.List;

import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;

import org.seedstack.jpa.BaseJpaRepository;

import com.capg.psa.domain.model.aggregate.Account;
import com.capg.psa.domain.repository.AccountRepository;

public class AccountJpaHibernate extends BaseJpaRepository<Account, Integer> implements AccountRepository {

	@Override
	public List<Account> all() {
		CriteriaBuilder	 cb = getEntityManager().getCriteriaBuilder();
		
		
		CriteriaQuery<Account> cquery = cb.createQuery(getAggregateRootClass());
		cquery.from(getAggregateRootClass());
		
		TypedQuery<Account> tquery = getEntityManager().createQuery(cquery);
		return tquery.getResultList();
	}

}
