package com.capg.psa.domain.model.aggregate;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;

import org.seedstack.business.domain.BaseAggregateRoot;

@Entity
public class Customer extends BaseAggregateRoot<Integer> {

	@Id
	@Column(name="customer_id")
	Integer customerId;
	
	@Column(name="customer_name")
	String customerName;
	
	@Column(name="customer_phNo")
	String phoneNo;
	
	
	@ManyToMany(cascade = { 
	        CascadeType.PERSIST, 
	        CascadeType.MERGE
	    })
	@JoinTable(name = "customer_account",
    joinColumns = @JoinColumn(name = "customerId"),
    inverseJoinColumns = @JoinColumn(name = "accountNo")
)
	private List<Account> accounts = new ArrayList<>();
	
	
	public Integer getCustomerId() {
		return customerId;
	}
	public void setCustomerId(Integer customerId) {
		this.customerId = customerId;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getPhoneNo() {
		return phoneNo;
	}
	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}
	public List<Account> getAccounts() {
		return accounts;
	}
	public void setAccounts(List<Account> accounts) {
		this.accounts = accounts;
	}
	public void addAccount(Account account) {
		accounts.add(account);		
	}

	public void removeAllAccounts() {
		accounts.clear();		
	}
	
}
