package com.capg.psa.domain.repository;

import java.util.List;

import org.seedstack.business.domain.Repository;

import com.capg.psa.domain.model.aggregate.Account;

public interface AccountRepository extends Repository<Account, Integer> {

	public List<Account> all();
	
}
