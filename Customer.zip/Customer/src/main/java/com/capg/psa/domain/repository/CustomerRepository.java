package com.capg.psa.domain.repository;

import java.util.List;

import org.seedstack.business.domain.Repository;

import com.capg.psa.domain.model.aggregate.Customer;

public interface CustomerRepository extends Repository<Customer, Integer> {

	public List<Customer> all();
	public List<Customer> byAccount(Integer accountNo);
}
