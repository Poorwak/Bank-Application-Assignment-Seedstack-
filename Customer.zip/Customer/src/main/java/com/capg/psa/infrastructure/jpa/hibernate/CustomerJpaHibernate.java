package com.capg.psa.infrastructure.jpa.hibernate;

import java.util.List;

import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;

import org.seedstack.jpa.BaseJpaRepository;

import com.capg.psa.domain.model.aggregate.Customer;
import com.capg.psa.domain.repository.CustomerRepository;

public class CustomerJpaHibernate extends BaseJpaRepository<Customer, Integer> implements CustomerRepository{

	@Override
	public List<Customer> all() {
		CriteriaBuilder	 cb = getEntityManager().getCriteriaBuilder();
		
		
		CriteriaQuery<Customer> cquery = cb.createQuery(getAggregateRootClass());
		cquery.from(getAggregateRootClass());
		
		TypedQuery<Customer> tquery = getEntityManager().createQuery(cquery);
		return tquery.getResultList();
	}

	@Override
	public List<Customer> byAccount(Integer accountNo) {
		CriteriaBuilder	 cb = getEntityManager().getCriteriaBuilder();
		
		
		CriteriaQuery<Customer> cquery = cb.createQuery(getAggregateRootClass());
		cquery.from(getAggregateRootClass());
		
		TypedQuery<Customer> tquery = getEntityManager().createQuery(cquery);
		return tquery.getResultList();
	}

}
