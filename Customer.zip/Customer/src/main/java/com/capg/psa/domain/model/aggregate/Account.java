package com.capg.psa.domain.model.aggregate;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToMany;

import org.seedstack.business.domain.BaseAggregateRoot;

@Entity
public class Account extends BaseAggregateRoot<Integer>{

	@Id
	@Column(name="account_no")
	Integer accountNo;
	
	@Column(name="account_type")
	String accountType;
	
	 @ManyToMany(mappedBy = "accounts")
	 private List<Customer> customers = new ArrayList<>();
	
	public Integer getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(Integer accountNo) {
		this.accountNo = accountNo;
	}
	public String getAccountType() {
		return accountType;
	}
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}
	
	
}
